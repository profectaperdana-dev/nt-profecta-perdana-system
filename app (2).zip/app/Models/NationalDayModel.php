<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NationalDayModel extends Model
{
    use HasFactory;
    protected $table = 'national_days';
}
