<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProspectiveEmployeeModel extends Model
{
    use HasFactory;

    protected $table = 'prospective_employees';
}
